package tqs.assignment.airquality;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirQualityApplicationTests {

	@Test
	void contextLoads() {
	}

}
